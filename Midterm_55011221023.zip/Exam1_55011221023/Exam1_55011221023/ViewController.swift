//
//  ViewController.swift
//  Exam1_55011221023
//
//  Created by Student on 10/10/14.
//  Copyright (c) 2014 Student. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var name_inp: UITextField!
    @IBOutlet var Valume_inp: UITextField!
    @IBOutlet var price_inp: UITextField!
    @IBOutlet var table_output: UITableView!
    
    @IBAction func bt_total(sender: AnyObject) {
        
    }
 
    @IBAction func BT_profit(sender: AnyObject) {
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

